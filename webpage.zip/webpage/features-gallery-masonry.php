<!DOCTYPE html>
<html lang="en-US" class="scheme_original">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="format-detection" content="telephone=no">
	<link rel="icon" type="image/x-icon" href="images/favicon.ico" />
	<title>Oldstory – Whiskey Bar HTML</title>
	<link rel="stylesheet" type="text/css" media="all" href="js/vendor/essential-grid/public/assets/css/settings.css">
	<link rel="stylesheet" type="text/css" media="all" href="js/vendor/essential-grid/public/assets/css/lightbox.css">
	
	
	
	
	
	
	
	
	<link rel="stylesheet" type="text/css" media="all" href="css/fontello/css/fontello.min.css" />
	<link rel="stylesheet" type="text/css" media="all" href="css/style.css" />
	<link rel="stylesheet" type="text/css" media="all" href="css/core.animation.min.css" />
	<link rel="stylesheet" type="text/css" media="all" href="css/theme.shortcodes.css" />
	
	<link rel="stylesheet" type="text/css" media="all" href="css/skin.css" />
	<link rel="stylesheet" type="text/css" media="all" href="css/responsive.css" />
	
	

</head>

<body class="page body_filled article_style_stretch scheme_original top_panel_above sidebar_hide">
			
	<div class="body_wrap header_style_8">

		<div class="page_wrap">
			
			<div class="top_panel_fixed_wrap"></div>

			<header class="top_panel_wrap top_panel_style_8 scheme_original">
	<div class="top_panel_wrap_inner top_panel_inner_style_8 top_panel_position_above">
		<div class="top_panel_middle" >
			<div class="content_wrap">
				<div class="contact_info">
					<address class="contact_address icon-location">
						123, New Lenox Chicago,<br>IL 60606
					</address>
				</div>
				<div class="contact_logo">
					<div class="logo">
						<a href="index.html">
							<img src="images/logo.png" class="logo_main" alt="" width="132" height="54">
						<img src="images/logo.png" class="logo_fixed" alt="" width="132" height="54"></a>
					</div>
				</div>
				<div class="menu_pushy_wrap clearfix">
					<a href="#" class="menu_pushy_button">
						MENU
						<span class=" icon-menu"></span>
					</a>
				</div>
			</div>
		</div>
	</div>
</header>

<nav class="menu_pushy_nav_area pushy pushy-left scheme_dark">
	<div class="pushy_inner">
		<a href="#" class="close-pushy"></a>
		<div class="logo">
			<a href="index.html">
				<img src="images/logo.png" class="logo_side" alt="" width="132" height="54">
			</a>
		</div>
		<ul id="menu_pushy" class="menu_pushy_nav">
			<li class="menu-item  menu-item-has-children">
				<a href="#">Home</a>
				<ul class="sub-menu">
					<li class="menu-item menu-item-object-page ">
						<a href="index.html">Home 1</a>
					</li>
					<li class="menu-item menu-item-object-page ">
						<a href="index2.html">Home 2</a>
					</li>
				</ul>
			</li>
			<li class="menu-item current-menu-ancestor menu-item-has-children">
				<a href="#">Features</a>
				<ul class="sub-menu">
					<li class="menu-item menu-item-object-page ">
						<a href="features-typography.html">Typography</a>
					</li>
					<li class="menu-item menu-item-object-page ">
						<a href="features-shortcodes.html">Shortcodes</a>
					</li>
					<li class="menu-item ">
						<a href="features-page404.html">Page 404</a>
					</li>
					<li class="menu-item current-menu-ancestor current-menu-parentt menu-item-has-children">
						<a href="#">Gallery</a>
						<ul class="sub-menu">
							<li class="menu-item menu-item-object-page current-menu-item">
								<a href="features-gallery-masonry.html">Masonry</a>
							</li>
							<li class="menu-item menu-item-object-page ">
								<a href="features-gallery-grid.html">Grid</a>
							</li>
							<li class="menu-item menu-item-object-page ">
								<a href="features-gallery-cobbles.html">Cobbles</a>
							</li>
						</ul>
					</li>
				</ul>
			</li>
			<li class="menu-item menu-item-has-children ">
				<a href="#">About us</a>
				<ul class="sub-menu">
					<li class="menu-item menu-item-object-page ">
						<a href="about-us-about-us.html">About us</a>
					</li>
					<li class="menu-item ">
						<a href="about-us-bartender.html">Bartender&#8217;s Page</a>
					</li>
				</ul>
			</li>
			<li class="menu-item menu-item-has-children ">
				<a href="#">News</a>
				<ul class="sub-menu">
					<li class="menu-item ">
						<a href="news-post-formats.html">Post Formats</a>
					</li>
					<li class="menu-item ">
						<a href="news-classic.html">Classic Style</a>
					</li>
					<li class="menu-item menu-item-has-children ">
						<a href="#">Masonry Layout</a>
						<ul class="sub-menu">
							<li class="menu-item ">
								<a href="news-masonry-layout-2-columns.html">Masonry (2 columns)</a>
							</li>
							<li class="menu-item ">
								<a href="news-masonry-layout-3-columns.html">Masonry (3 columns)</a>
							</li>
						</ul>
					</li>
					<li class="menu-item menu-item-has-children ">
						<a href="#">Portfolio Layout</a>
						<ul class="sub-menu">
							<li class="menu-item ">
								<a href="news-portfolio-layout-2-columns.html">Portfolio (2 columns)</a>
							</li>
							<li class="menu-item ">
								<a href="news-portfolio-layout-3-columns.html">Portfolio (3 columns)</a>
							</li>
						</ul>
					</li>
				</ul>
			</li>
			<li class="menu-item menu-item-object-page ">
				<a href="menu.html">Menu</a>
			</li>
			<li class="menu-item menu-item-has-children ">
				<a href="#">Store</a>
				<ul class="sub-menu">
					<li class="menu-item menu-item-object-page ">
						<a href="store-shop.html">Shop</a>
					</li>
					<li class="menu-item menu-item-object-page ">
						<a href="store-cart.html">Cart</a>
					</li>
					<li class="menu-item menu-item-object-page ">
						<a href="store-checkout.html">Checkout</a>
					</li>
				</ul>
			</li>
			<li class="menu-item menu-item-object-page ">
				<a href="contacts.html">Contacts</a>
			</li>
		</ul>
	</div>
</nav>

<!-- Site Overlay -->
<div class="site-overlay"></div>
<div class="header_mobile">
	<div class="content_wrap">
		<div class="menu_button icon-menu"></div>
		<div class="logo">
			<a href="index.html">
				<img src="images/logo.png" class="logo_main" alt="" width="132" height="54">
			</a>
		</div>
	</div>
	<div class="side_wrap">
		<div class="close">Close</div>
		<div class="panel_top">
			<nav class="menu_main_nav_area">
				<ul id="menu_main" class="menu_main_nav">
					<li class="menu-item  menu-item-has-children">
						<a href="#">Home</a>
						<ul class="sub-menu">
							<li class="menu-item menu-item-object-page ">
								<a href="index.html">Home 1</a>
							</li>
							<li class="menu-item menu-item-object-page ">
								<a href="index2.html">Home 2</a>
							</li>
						</ul>
					</li>
					<li class="menu-item menu-item-has-children current-menu-ancestor">
						<a href="#">Features</a>
						<ul class="sub-menu">
							<li class="menu-item menu-item-object-page ">
								<a href="features-typography.html">Typography</a>
							</li>
							<li class="menu-item menu-item-object-page ">
								<a href="features-shortcodes.html">Shortcodes</a>
							</li>
							<li class="menu-item ">
								<a href="features-page404.html">Page 404</a>
							</li>
							<li class="menu-item menu-item-has-children current-menu-ancestor current-menu-parentt">
								<a href="#">Gallery</a>
								<ul class="sub-menu">
									<li class="menu-item menu-item-object-page current-menu-item">
										<a href="features-gallery-masonry.html">Masonry</a>
									</li>
									<li class="menu-item menu-item-object-page ">
										<a href="features-gallery-grid.html">Grid</a>
									</li>
									<li class="menu-item menu-item-object-page ">
										<a href="features-gallery-cobbles.html">Cobbles</a>
									</li>
								</ul>
							</li>
						</ul>
					</li>
					<li class="menu-item menu-item-has-children ">
						<a href="#">About us</a>
						<ul class="sub-menu">
							<li class="menu-item menu-item-object-page ">
								<a href="about-us-about-us.html">About us</a>
							</li>
							<li class="menu-item ">
								<a href="about-us-bartender.html">Bartender&#8217;s Page</a>
							</li>
						</ul>
					</li>
					<li class="menu-item menu-item-has-children ">
						<a href="#">News</a>
						<ul class="sub-menu">
							<li class="menu-item ">
								<a href="news-post-formats.html">Post Formats</a>
							</li>
							<li class="menu-item ">
								<a href="news-classic.html">Classic Style</a>
							</li>
							<li class="menu-item menu-item-has-children ">
								<a href="#">Masonry Layout</a>
								<ul class="sub-menu">
									<li class="menu-item ">
										<a href="news-masonry-layout-2-columns.html">Masonry (2 columns)</a>
									</li>
									<li class="menu-item ">
										<a href="news-masonry-layout-3-columns.html">Masonry (3 columns)</a>
									</li>
								</ul>
							</li>
							<li class="menu-item menu-item-has-children ">
								<a href="#">Portfolio Layout</a>
								<ul class="sub-menu">
									<li class="menu-item ">
										<a href="news-portfolio-layout-2-columns.html">Portfolio (2 columns)</a>
									</li>
									<li class="menu-item ">
										<a href="news-portfolio-layout-3-columns.html">Portfolio (3 columns)</a>
									</li>
								</ul>
							</li>
						</ul>
					</li>
					<li class="menu-item menu-item-object-page ">
						<a href="menu.html">Menu</a>
					</li>
					<li class="menu-item menu-item-has-children ">
						<a href="#">Store</a>
						<ul class="sub-menu">
							<li class="menu-item menu-item-object-page ">
								<a href="store-shop.html">Shop</a>
							</li>
							<li class="menu-item menu-item-object-page ">
								<a href="store-cart.html">Cart</a>
							</li>
							<li class="menu-item menu-item-object-page ">
								<a href="store-checkout.html">Checkout</a>
							</li>
						</ul>
					</li>
					<li class="menu-item menu-item-object-page ">
						<a href="contacts.html">Contacts</a>
					</li>
				</ul>
			</nav>
		</div>
		<div class="panel_bottom"></div>
	</div>
	<div class="mask"></div>
</div>


	        <div class="top_panel_title top_panel_style_8 breadcrumbs_present scheme_original">
	<div class="top_panel_title_inner top_panel_inner_style_8 breadcrumbs_present_inner">
		<div class="content_wrap">
			<div class="breadcrumbs"><a class="breadcrumbs_item home" href="#">Home</a><span class="breadcrumbs_delimiter"></span><span class="breadcrumbs_item current">Masonry</span>
			</div>
		</div>
	</div>
</div>

			<div class="page_content_wrap page_paddings_no">

				<div class="content">
					<article class="post_item post_item_single page">
						<div class="post_content">

							<section class="">
								<div class="container">
									<div class="sc_section margin_bottom_huge aligncenter">
										<div class="sc_section_inner">
											<h5 class="sc_title mtn16em mb03rem">photo stream</h5>
											<h1 class="sc_title margin_top_null margin_bottom_large">gallery</h1>
											<article class="myportfolio-container minimal-light" id="esg-grid-2-1-wrap">
												<div id="esg-grid-2-1" class="esg-grid">
													<article class="esg-filters esg-singlefilters">
														<div class="esg-filter-wrapper  esg-fgc-2">
															<div class="esg-filterbutton selected esg-allfilter" data-filter="filterall" data-fid="-1">
																<span>All</span>
															</div>
															<div class="esg-filterbutton" data-fid="34" data-filter="filter-latest-events">
																<span>Latest Events</span>
																<span class="esg-filter-checked">
																	<i class="eg-icon-ok-1"></i>
																</span>
															</div>
															<div class="esg-filterbutton" data-fid="36" data-filter="filter-coctails">
																<span>Coctails</span>
																<span class="esg-filter-checked">
																	<i class="eg-icon-ok-1"></i>
																</span>
															</div>
															<div class="esg-filterbutton" data-fid="37" data-filter="filter-longdrinks">
																<span>Longdrinks</span>
																<span class="esg-filter-checked">
																	<i class="eg-icon-ok-1"></i>
																</span>
															</div>
															<div class="esg-filterbutton" data-fid="35" data-filter="filter-food">
																<span>Food</span>
																<span class="esg-filter-checked">
																	<i class="eg-icon-ok-1"></i>
																</span>
															</div>
															<div class="eg-clearfix"></div>
														</div>
													</article>
													<div class="esg-clear-no-height"></div>
													<ul>
														<li class="filterall filter-gallery filter-food filter-latest-events eg-washington-wrapper eg-post-id-821" data-date="1455200294">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/gallery-3.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-821 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-821 esgbox" href="images/gallery-3.jpg" lgtitle="Our Menu to Compliment Your Drink">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-821 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-821" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
														<li class="filterall filter-gallery filter-coctails filter-latest-events eg-washington-wrapper eg-post-id-822" data-date="1455200306">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/home2_features3.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-822 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-822 esgbox" href="images/home2_features3.jpg" lgtitle="Our Restaurant">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-822 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-822" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
														<li class="filterall filter-gallery filter-coctails filter-food eg-washington-wrapper eg-post-id-823" data-date="1455200312">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/gallery-2.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-823 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-823 esgbox" href="images/gallery-2.jpg" lgtitle="Our Whicky Selection">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-823 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-823" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
														<li class="filterall filter-gallery filter-food filter-longdrinks eg-washington-wrapper eg-post-id-824" data-date="1455200318">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/gallery-4.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-824 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-824 esgbox" href="images/gallery-4.jpg" lgtitle="Japanese Scotch Whisky">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-824 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-824" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
														<li class="filterall filter-gallery filter-latest-events filter-longdrinks eg-washington-wrapper eg-post-id-825" data-date="1455200326">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/gallery-1.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-825 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-825 esgbox" href="images/gallery-1.jpg" lgtitle="How We Started">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-825 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-825" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
														<li class="filterall filter-gallery filter-coctails filter-food eg-washington-wrapper eg-post-id-826" data-date="1455200341">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/gallery_img3.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-826 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-826 esgbox" href="images/gallery_img3.jpg" lgtitle="Our Best Meat">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-826 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-826" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
														<li class="filterall filter-gallery filter-coctails filter-longdrinks eg-washington-wrapper eg-post-id-827" data-date="1455200347">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/gallery-5.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-827 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-827 esgbox" href="images/gallery-5.jpg" lgtitle="Making Coctails">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-827 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-827" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
														<li class="filterall filter-gallery filter-food filter-latest-events eg-washington-wrapper eg-post-id-828" data-date="1455200356">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/bar.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-828 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-828 esgbox" href="images/bar.jpg" lgtitle="Our Events">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-828 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-828" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
														<li class="filterall filter-gallery filter-coctails filter-food filter-longdrinks eg-washington-wrapper eg-post-id-829" data-date="1455200363">
															<div class="esg-media-cover-wrapper">
																<div class="esg-entry-media">
																	<img src="images/gallery-6.jpg" alt="">
																</div>
																<div class="esg-entry-cover esg-fade" data-delay="0">
																	<div class="esg-overlay esg-fade eg-washington-container" data-delay="0">
																	</div>
																	<div class="esg-center eg-post-829 eg-washington-element-0-a esg-falldown" data-delay="0.1">
																		<a class="eg-washington-element-0 eg-post-829 esgbox" href="images/gallery-6.jpg" lgtitle="Mixing a Classic Cocktails">
																			<i class="eg-icon-search"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-post-829 eg-washington-element-1-a esg-falldown" data-delay="0.2">
																		<a class="eg-washington-element-1 eg-post-829" href="#" target="_self">
																			<i class="eg-icon-link"></i>
																		</a>
																	</div>
																	<div class="esg-center eg-washington-element-8 esg-none esg-clear"></div>
																	<div class="esg-center eg-washington-element-9 esg-none esg-clear"></div>
																</div>
															</div>
														</li>
													</ul>
												</div>
											</article>
											<div class="clear"></div>
										</div>
									</div>
								</div>
							</section>

							<section class="bg_image_15 spt4rem spb365rem">
								<div class="container">
									<div class="sc_content content_wrap">
										<div class="sc_section aligncenter">
											<div class="sc_section_inner">
												<h2 class="sc_title sc_title_style_4 margin_top_no margin_bottom_small white">stay in touch with updates</h2>
												<div class="sc_emailer sc_emailer_opened">
													<form class="sc_emailer_form">
														<input type="text" class="sc_emailer_input" name="email" value="" placeholder="Enter Your Email">
														<a href="#" class="sc_emailer_button sc_button sc_button_style_filled style_color_light" title="Submit" data-group="Updates">Submit</a>
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
							</section>

						</div>
					</article>
				</div>

			</div>
			
			<footer class="footer_wrap widget_area scheme_original ">
				<div class="footer_wrap_inner widget_area_inner">
					<div class="content_wrap">
						<div class="columns_wrap">
							<aside class="widget_number_1 column-1_3 widget widget_text">
								<h2 class="widget_title">Email Address</h2>
								<div class="textwidget">
									<a href="info@yoursite.com">info@yoursite.com</a><br>
									<a href="www.yoursite.com">www.yoursite.com</a>
								</div>
							</aside><aside class="widget_number_2 column-1_3 widget widget_text">
								<h2 class="widget_title">Phones &#038; Faxes</h2>
								<div class="textwidget">
									+1(800)123-4567<br>
									+1(800)123-4566
								</div>
							</aside><aside class="widget_number_3 column-1_3 widget widget_text">
								<h2 class="widget_title">Bar&#8217;s Location</h2>
								<div class="textwidget">
									176 W Lorem Street<br>
									New York, NY 10014
								</div>
							</aside>
						</div>
					</div>
				</div>
			</footer>

			<footer class="contacts_wrap scheme_original show-footer-border-no">
				<div class="contacts_wrap_inner">
					<div class="content_wrap">
						<div class="logo">
							<a href="index.html">
								<img src="images/logo_footer.png" class="logo_footer" alt="" width="132" height="54">
							</a>
						</div>
					</div>
				</div>
			</footer>	
	
			<div class="copyright_wrap copyright_style_socials scheme_original">
				<div class="copyright_wrap_inner">
					<div class="content_wrap">
						<div class="copyright_text">
							<a href="http://ancorathemes.com/">Ancora</a> © 2015 All Rights Reserved <a href="http://ancorathemes.com/">Terms of Use</a> and <a href="http://ancorathemes.com/">Privacy Policy</a>
						</div>
						<div class="sc_socials sc_socials_type_icons sc_socials_shape_square sc_socials_size_tiny">
							<div class="sc_socials_item">
								<a href="#" target="_blank" class="social_icons social_facebook">
									<span class="icon-facebook"></span>
								</a>
							</div><div class="sc_socials_item">
								<a href="#" target="_blank" class="social_icons social_instagramm">
									<span class="icon-instagramm"></span>
								</a>
							</div><div class="sc_socials_item">
								<a href="#" target="_blank" class="social_icons social_gpl">
									<span class="icon-gpl"></span>
								</a>
							</div><div class="sc_socials_item">
								<a href="#" target="_blank" class="social_icons social_tripadvisor">
									<span class="icon-tripadvisor"></span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>	 
							
		</div>

	</div>
	
	
<a href="#" class="scroll_to_top icon-up" title="Scroll to top"></a>

	<script type='text/javascript' src='js/vendor/jquery-1.12.3.min.js'></script>
	<script type='text/javascript' src='js/vendor/jquery-migrate.min.js'></script>
	<script type="text/javascript" src="js/vendor/essential-grid/public/assets/js/lightbox.js"></script>
	<script type="text/javascript" src="js/vendor/essential-grid/public/assets/js/jquery.themepunch.tools.min.js"></script>
	<script type="text/javascript" src="js/vendor/essential-grid/public/assets/js/jquery.themepunch.essential.min.js"></script>
	
	
	<script type='text/javascript' src='js/custom/__main.js'></script>
	<script type='text/javascript' src='js/vendor/jquery.cookie.min.js'></script>
	<script type='text/javascript' src='js/vendor/superfish.min.js'></script>
	<script type='text/javascript' src='js/custom/jquery.slidemenu.min.js'></script>
	<script type='text/javascript' src='js/custom/core.utils.min.js'></script>
	<script type='text/javascript' src='js/custom/core.init.js'></script>
	<script type='text/javascript' src='js/custom/theme.init.min.js'></script>
	
	<script type='text/javascript' src='js/custom/theme.shortcodes.js'></script>
	<script type='text/javascript' src='js/vendor/core.min.js'></script>
	<script type='text/javascript' src='js/vendor/widget.min.js'></script>
	<script type='text/javascript' src='js/vendor/tabs.min.js'></script>
	<script type='text/javascript' src='js/vendor/effect.min.js'></script>
	<script type='text/javascript' src='js/vendor/effect-fade.min.js'></script>
	
	
	
	
	
	
	
	
	
	

</body>
</html>
